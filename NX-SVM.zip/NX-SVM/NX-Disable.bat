@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem ===========================================================================
rem  Synez-Scewin V2 — NX OFF  (AMD NX / Intel XD)
rem
rem  Patches nvram.txt only (does NOT touch the BIOS). Run Import.bat after.
rem  Every write passes --optional to nvram_set.exe: knobs that don't exist
rem  on this board log as SKIP ("mobo-dependent"), not FAIL. AMD and Intel
rem  names are stacked — only the ones present on this board patch.
rem
rem    AMD    NX Mode              0x0       No-execute page protection (DEP)
rem    Intel  Execute Disable Bit  Disabled  Intel's NX (XD)
rem
rem  Intel knobs are written by option LABEL, not index — Intel boards don't
rem  agree on the [xx] encoding. Label not in the Options list = SKIP.
rem  Appends to nvram_patch_report.txt (never truncates it).
rem ===========================================================================

set "ROOT=%~dp0"
set "NVRAM=%ROOT%nvram.txt"
set "NVSET=%ROOT%nvram_set.exe"
set "PATCH_LOG=%ROOT%nvram_patch_report.txt"

set /a BAT_OK=0
set /a BAT_FAIL=0

if not exist "!NVSET!" ( echo FAIL: nvram_set.exe missing & exit /b 1 )
if not exist "!NVRAM!" ( echo FAIL: nvram.txt missing     & exit /b 1 )

(
  echo.
  echo # --- NX OFF !DATE! !TIME! ---
) >> "!PATCH_LOG!"


rem  AMD NX
call :try "NX Mode"                    0x0

rem  Intel NX (XD)
call :try "Execute Disable Bit"        "Disabled"
call :try "Intel Execute Disable Bit"  "Disabled"


(
  echo # --- NX OFF SUMMARY !DATE! !TIME! ---
  echo # OK=!BAT_OK!  FAIL=!BAT_FAIL!  ^(SKIP=mobo-dependent, see log^)
) >> "!PATCH_LOG!"

echo.
echo OK=!BAT_OK!  FAIL=!BAT_FAIL!   ^(details: nvram_patch_report.txt^)
echo Run Import.bat to write nvram.txt to the BIOS, then power cycle.

if !BAT_FAIL! gtr 0 exit /b 1
exit /b 0


rem ===========================================================================
rem  Helper — --optional: missing knob = SKIP (exit 0); real failures exit 1.
rem ===========================================================================

:try
set "P_Q=%~1"
set "P_V=%~2"
"!NVSET!" "!NVRAM!" "!P_Q!" "!P_V!" --optional --report "!PATCH_LOG!" >nul 2>&1
if errorlevel 1 (
    set /a BAT_FAIL+=1
    echo FAIL  !P_Q!  !P_V!
) else (
    set /a BAT_OK+=1
    echo OK    !P_Q!  !P_V!
)
exit /b 0
